import { useMemo } from "react";
import {
  MaterialReactTable,
  useMaterialReactTable,
  type MRT_ColumnDef,
} from "material-react-table";
import { Box, IconButton, Tooltip, Typography, Alert } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import type { StyleContext } from "./material-consumption/material-consumption.types";
// import type { StyleContext } from "./material-consumption.types";

import EditIcon from "@mui/icons-material/Edit"; // Add this icon import

// Explicitly type the inbound data contract mapping your C# EF Core Ledger structure
export interface StyleMaterialConsumptionLedgerRow {
  buyerCode: number;
  order: string;
  typeCode: number;
  styleCode: string;
  color: string;
  size: string;
  stockCode: string;
  itemCode: string;
  feature1: string;
  feature2: string;
  feature3: string;
  feature4: string;
  consumptionUnit: string;
  quantityPerGarment: number;
  percentageAllowance: number;
  itemUnit: string;
  totalConsumption: number;
  supplierCode: string;
}

interface LedgerGridProps {
  styleContext: StyleContext;
  ledgerData: StyleMaterialConsumptionLedgerRow[];
  isLoading: boolean;
  onRefresh: () => void;
  onEditRowSelect: (row: StyleMaterialConsumptionLedgerRow) => void; // 1. Add this prop interface route
}

export default function ConsumptionLedgerGrid({
  styleContext,
  ledgerData,
  isLoading,
  onRefresh,
  onEditRowSelect,
}: LedgerGridProps) {
  // 1. Define the Columns structure matching your exact PascalCase property dictionary names
  const columns = useMemo<MRT_ColumnDef<StyleMaterialConsumptionLedgerRow>[]>(
    () => [
      {
        accessorKey: "itemCode",
        header: "Item ID",
        size: 90,
        muiTableBodyCellProps: {
          sx: { fontFamily: "monospace", fontWeight: "bold" },
        },
      },
      {
        accessorKey: "color",
        header: "Garm. Colour",
        size: 110,
        Cell: ({ cell }) => cell.getValue<string>() || "ALL COLOURS",
      },
      {
        accessorKey: "size",
        header: "Garm. Size",
        size: 100,
        Cell: ({ cell }) => cell.getValue<string>() || "ALL SIZES",
      },
      {
        // Combined virtual column replicating the Clipper feature string block row summary display
        header: "Configuration Parameters (Ft1 - Ft4)",
        size: 200,
        accessorFn: (row) =>
          `${row.feature1 || "-"} / ${row.feature2 || "-"} / ${row.feature3 || "-"} / ${row.feature4 || "-"}`,
      },
      {
        accessorKey: "consumptionUnit",
        header: "C/Unit",
        size: 80,
      },
      {
        accessorKey: "quantityPerGarment",
        header: "Qty/Garm",
        size: 100,
        type: "number",
        Cell: ({ cell }) => cell.getValue<number>().toFixed(3),
      },
      {
        accessorKey: "percentageAllowance",
        header: "Allow. %",
        size: 90,
        type: "number",
        Cell: ({ cell }) => `${cell.getValue<number>().toFixed(1)}%`,
      },
      {
        accessorKey: "itemUnit",
        header: "F/Unit",
        size: 80,
      },
      {
        accessorKey: "totalConsumption",
        header: "Total Consumption",
        size: 140,
        type: "number",
        muiTableBodyCellProps: {
          sx: { fontWeight: "bold", color: "#2e7d32", textAlign: "right" },
        },
        Cell: ({ cell }) => cell.getValue<number>().toLocaleString(),
      },
      {
        accessorKey: "supplierCode",
        header: "Supplier",
        size: 100,
      },
    ],
    [],
  );

  // 2. Enforce the strict Clipper Cascading Delete Verification Guard Hook
  const handleDeleteEntry = async (row: StyleMaterialConsumptionLedgerRow) => {
    const confirmation = window.confirm(
      `Are you sure you want to delete this consumption assignment ledger entry for item [${row.itemCode}]?`,
    );
    if (!confirmation) return;

    try {
      // Build the verification query scope URL string matching your exact transactional constraints
      const deleteUrl = `/api/materialConsumption/delete-entry?buyerCode=${row.buyerCode}&order=${encodeURIComponent(row.order)}&typeCode=${row.typeCode}&styleCode=${encodeURIComponent(row.styleCode)}&stockCode=${row.stockCode}&itemCode=${row.itemCode}&color=${encodeURIComponent(row.color)}&size=${encodeURIComponent(row.size)}`;

      const response = await fetch(deleteUrl, { method: "DELETE" });

      if (response.status === 400) {
        // Handle PO already raised error state safely from C# backend interception rules
        const errorJson = await response.json();
        alert(
          `Deletion Aborted: ${errorJson.message || "A Purchase Order has already been raised for this material line item. Modifications are blocked."}`,
        );
        return;
      }

      if (!response.ok) throw new Error("Network transaction failed.");

      alert(
        "Ledger line record removed and quantities adjusted downstream successfully.",
      );
      onRefresh(); // Re-trigger the RTK Cache query invalidate to update the bottom screen rows instantly
    } catch (err: unknown) {
      alert(
        "Failed to complete the record delete transaction request on SQL Server.",
      );
    }
  };

  const table = useMaterialReactTable({
    columns,
    data: ledgerData,
    state: { isLoading },
    enablePagination: true,
    enableRowActions: true,
    positionActionsColumn: "last",
    initialState: {
      pagination: { pageSize: 5, pageIndex: 0 },
      density: "compact",
    },

    renderRowActions: ({ row }) => (
      <Box
        sx={{
          display: "flex",
          gap: 1,
        }}
      >
        {/* Edit Action Button Trigger */}
        <Tooltip title="Load this row record back up into form parameters for modification">
          <IconButton
            color="primary"
            onClick={() => onEditRowSelect(row.original)}
          >
            <EditIcon />
          </IconButton>
        </Tooltip>

        <Tooltip title="Delete entry line and adjust inventory totals">
          <IconButton
            color="error"
            onClick={() => handleDeleteEntry(row.original)}
          >
            <DeleteIcon />
          </IconButton>
        </Tooltip>
      </Box>
    ),
  });

  return (
    <Box sx={{ mt: 3 }}>
      <Typography
        variant="subtitle2"
        sx={{ fontWeight: "bold", mb: 1, color: "#1a237e" }}
      >
        [ CONSOLIDATED STYLE RUNNING PRODUCTION LEDGER MATRIX ]
      </Typography>

      {ledgerData.length === 0 && !isLoading ? (
        <Alert severity="info" variant="outlined">
          No raw material consumption entries have been logged for Style:{" "}
          <strong>{styleContext.styleCode}</strong> yet. Use the data panels
          above to calculate and add items.
        </Alert>
      ) : (
        <MaterialReactTable table={table} />
      )}
    </Box>
  );
}
