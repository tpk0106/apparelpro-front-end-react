import { useState, useCallback, useEffect } from "react";
import { Box, Paper, Typography, Alert } from "@mui/material";
import Grid from "@mui/material/Grid";
import ConsumptionScopeHeader from "./consumption-scope-header.component";
import MaterialMasterList from "./material-master-list.component"; // type OrderItemLookupRow,
import ConsumptionEntryForm from "./consumption-entry-form.component";
// import OrderItemLookupRow from "./material-master-list.component";
// import type ConsumptionLedgerGrid from "./consumption-ledger-grid.component";

//import { useGetBreakdownByStyleQuery } from "./materialConsumptionApi";

// Import your custom RTK Query data fetch hooks
import {
  useGetAvailableMaterialsQuery,
  useGetBreakdownByStyleQuery,
} from "../../services/material-consumption.services"; // Fetch mapping endpoint

import type {
  OrderItemServiceModel,
  SelectedScopeContext,
} from "./material-consumption.types";
import ConsumptionLedgerGrid, {
  type StyleMaterialConsumptionLedgerRow,
} from "../consumption-ledger-grid.component";

export default function MaterialConsumption() {
  const [scopeContext, setScopeContext] = useState<SelectedScopeContext | null>(
    null,
  );

  // 2. FIXED: Declare the state hook to track a true data item instance row (REMOVED 'typeof')
  const [activeSelection, setActiveSelection] =
    useState<OrderItemServiceModel | null>(null);

  // 1. ADD state memory to hold the specific row record currently being edited
  const [editingRow, setEditingRow] =
    useState<StyleMaterialConsumptionLedgerRow | null>(null);

  // Memoized callback handler tracking context alterations
  const handleScopeContextChange = useCallback(
    (context: SelectedScopeContext | null) => {
      setScopeContext(context);
      setActiveSelection(null);
      setEditingRow(null); // Clear editing states on scope shift
    },
    [],
  );

  // const [scopeContext, setScopeContext] = useState<SelectedScopeContext | null>(
  //   null,
  // );
  // const [activeSelection, setActiveSelection] = useState<
  //   typeof OrderItemLookupRow | null
  // >(null);

  // // Stable callback handler to prevent rendering timing loop conflicts
  // const handleScopeContextChange = useCallback(
  //   (context: SelectedScopeContext | null) => {
  //     setScopeContext(context);
  //     setActiveSelection(null);
  //   },
  //   [],
  // );

  // Inside material-consumption.component.tsx:
  const { data: materialsData = [], isLoading: isChecklistLoading } =
    useGetAvailableMaterialsQuery(
      {
        buyerCode: scopeContext?.buyerCode ?? 0,
        order: scopeContext?.order ?? "",
        typeCode: scopeContext?.typeCode ?? 0,
        styleCode: scopeContext?.styleCode ?? "",
      },
      { skip: !scopeContext },
    );

  // Fetch the bottom ledger rows dynamically using your active selection context keys
  const {
    data: currentLedger = [],
    isLoading: isLedgerLoading,
    refetch,
  } = useGetBreakdownByStyleQuery(
    {
      buyerCode: scopeContext?.buyerCode ?? 0,
      order: scopeContext?.order ?? "",
      typeCode: scopeContext?.typeCode ?? 0,
      styleCode: scopeContext?.styleCode ?? "",
    },
    { skip: !scopeContext }, // Skip loading database records until header selection is complete
  );

  useEffect(() => {
    console.log("loaded buyer ", scopeContext?.buyerCode);
    console.log("loaded order ", scopeContext?.order);
    console.log("loaded type ", scopeContext?.typeCode);
    console.log("loaded style ", scopeContext?.styleCode);
    console.log("loaded style ledger ", currentLedger);
  });

  return (
    <Box sx={{ width: "100%", p: 1 }}>
      <Typography
        variant="h5"
        sx={{ fontWeight: "bold", color: "#1a237e", mb: 2 }}
      >
        Material Consumption Master Ledger
      </Typography>

      <ConsumptionScopeHeader onScopeChange={handleScopeContextChange} />

      {scopeContext ? (
        <Box>
          {/* Top Panel: Split Master Checklist & Data Form Controls */}
          <Grid container spacing={3}>
            {/* <Grid size={{ xs: 12, md: 4 }}>
              <Paper elevation={2} sx={{ p: 2, minHeight: "420px" }}>
                <MaterialMasterList
                  onSelectMaterial={(item) => setActiveSelection(item)}
                />
              </Paper>
            </Grid> */}

            <Grid size={{ xs: 12, md: 4 }}>
              <Paper elevation={2} sx={{ p: 2, minHeight: "420px" }}>
                {/* Pass the loaded materialsData array directly down as a prop */}
                <MaterialMasterList
                  materialsList={materialsData}
                  isLoading={isChecklistLoading}
                  onSelectMaterial={(item) => {
                    setActiveSelection(item);
                    setEditingRow(null); // Clear active editing if they select a brand new master category
                  }}
                />
              </Paper>
            </Grid>
            <Grid size={{ xs: 12, md: 8 }}>
              <Paper elevation={2} sx={{ p: 2, minHeight: "420px" }}>
                {activeSelection ? (
                  <ConsumptionEntryForm
                    styleContext={scopeContext}
                    selectedMaterial={activeSelection}
                    // 2. Pass down the editing row record memory and clear function
                    editingRow={editingRow}
                    onCommitSuccess={() => {
                      refetch();
                      setEditingRow(null); // Reset row mode on successful save
                    }} // Refresh the grid automatically on successful save
                  />
                ) : (
                  <Box
                    sx={{
                      height: "350px",
                      color: "text.secondary",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <Typography variant="body1">
                      ← Select an item from the left inventory checklist panel
                      to begin entering consumption details.
                    </Typography>
                  </Box>
                )}
              </Paper>
            </Grid>
          </Grid>

          {/* Bottom Panel: The Consolidated Continuous Spreadsheet Data Log */}
          <Paper elevation={3} sx={{ p: 2, mt: 3 }}>
            <ConsumptionLedgerGrid
              styleContext={scopeContext}
              ledgerData={currentLedger}
              isLoading={isLedgerLoading}
              onRefresh={() => refetch()}
              // 3. Mount the click handler to push selected rows straight up into edit state
              onEditRowSelect={(row) => {
                // Instantly focus the left selection category context
                setActiveSelection({
                  stockCode: row.stockCode,
                  itemCode: row.itemCode,
                  description: "Editing Active Item Line",
                });
                setEditingRow(row); // Set form to edit values
              }}
            />
          </Paper>
        </Box>
      ) : (
        <Alert
          severity="info"
          variant="outlined"
          sx={{ mt: 2, fontWeight: "bold" }}
        >
          Please select a Buyer, Purchase Order, Garment Type, and Style in the
          header above to load the consumption workspace.
        </Alert>
      )}
    </Box>
  );
}

// import { useState, useCallback } from "react";
// import { Box, Paper, Typography, Alert } from "@mui/material";
// import Grid from "@mui/material/Grid";
// import ConsumptionScopeHeader from "./consumption-scope-header.component";
// import type { SelectedScopeContext } from "./material-consumption.types";
// import MaterialMasterList, {
//   type OrderItemLookupRow,
// } from "./material-master-list.component";

// export default function MaterialConsumption() {
//   // Track our selected scope context safely
//   const [scopeContext, setScopeContext] = useState<SelectedScopeContext | null>(
//     null,
//   );
//   const [activeSelection, setActiveSelection] =
//     useState<OrderItemLookupRow | null>(null);

//   // Memoize the scope change handler to prevent re-triggering child lifecycles
//   const handleScopeContextChange = useCallback(
//     (context: SelectedScopeContext | null) => {
//       setScopeContext(context);
//       setActiveSelection(null);
//     },
//     [],
//   ); // Stable reference prevents cascading render loops

//   return (
//     <Box sx={{ width: "100%", p: 1 }}>
//       <Typography
//         variant="h5"
//         sx={{ fontWeight: "bold", color: "#1a237e", mb: 2 }}
//       >
//         Material Consumption Master Ledger
//       </Typography>

//       {/* Mount the header with the stable handler reference */}
//       <ConsumptionScopeHeader onScopeChange={handleScopeContextChange} />

//       {scopeContext ? (
//         <Grid container spacing={3}>
//           {/* Left Flank Panel: Master Material Checklist Selection List */}
//           <Grid size={{ xs: 12, md: 4 }}>
//             <Paper elevation={2} sx={{ p: 2, minHeight: "500px" }}>
//               <MaterialMasterList
//                 onSelectMaterial={(selectedItem) =>
//                   setActiveSelection(selectedItem)
//                 }
//               />
//             </Paper>
//           </Grid>

//           {/* Right Flank Panel: Dynamic Entry Data Input Form */}
//           <Grid size={{ xs: 12, md: 8 }}>
//             <Paper elevation={2} sx={{ p: 2, minHeight: "500px" }}>
//               {activeSelection ? (
//                 <Box>
//                   <Typography
//                     variant="h6"
//                     color="primary"
//                     sx={{ fontWeight: "bold" }}
//                   >
//                     Selected: {activeSelection.description} (
//                     {activeSelection.stockCode}/{activeSelection.itemCode})
//                   </Typography>
//                 </Box>
//               ) : (
//                 <Box
//                   sx={{
//                     height: "400px",
//                     color: "text.secondary",
//                     display: "flex",
//                     justifyContent: "center",
//                     alignItems: "center",
//                   }}
//                 >
//                   <Typography variant="body1">
//                     ← Select an item from the left inventory checklist panel to
//                     begin entering consumption details.
//                   </Typography>
//                 </Box>
//               )}
//             </Paper>
//           </Grid>
//         </Grid>
//       ) : (
//         <Alert
//           severity="info"
//           variant="outlined"
//           sx={{ mt: 2, fontWeight: "bold" }}
//         >
//           Please select a Buyer, Purchase Order, and Garment Style in the header
//           above to load the consumption entry workspace tables.
//         </Alert>
//       )}
//     </Box>
//   );
// }

// import { useState } from "react";
// import { Box, Paper, Typography, Alert } from "@mui/material";
// // In MUI v6, Grid imports directly handle responsive grids without 'item' tags
// import Grid from "@mui/material/Grid";
// import type { Style } from "../../interfaces/OrderManagement/Style"; // Your global style model layout
// import MaterialMasterList from "./material-master-list.component"; // We build this next step
// import ConsumptionEntryForm from "./consumption-entry-form.component"; // Detail form layout panel

// interface MaterialConsumptionProps {
//   buyerCode: number;
//   order: string;
//   selectedStyleFromGrid: Style | null;
// }
// const MaterialConsumption = ({
//   buyerCode,
//   order,
//   selectedStyleFromGrid,
// }: MaterialConsumptionProps) => {
//   // Local state to keep track of whichever material is currently clicked on the left list
//   const [activeSelection, setActiveSelection] = useState<{
//     stockCode: string;
//     itemCode: string;
//     description: string;
//   } | null>(null);

//   // Safety guard clause in case a style row hasn't been selected from the main grid yet
//   if (!selectedStyleFromGrid) {
//     return (
//       <Box sx={{ padding: "3px" }}>
//         <Alert severity="info" variant="filled">
//           No Style context selected. Please return to the{" "}
//           <strong>[Style Details]</strong> tab and click the{" "}
//           <strong>Grid matrix button</strong> on a style row to begin
//           calculating material consumption.
//         </Alert>
//       </Box>
//     );
//   }

//   const parentStyleContext = {
//     buyerCode,
//     order,
//     typeCode: selectedStyleFromGrid.typeCode,
//     styleCode: selectedStyleFromGrid.styleCode,
//     bulkQuantity: Number(selectedStyleFromGrid.quantity) || 0,
//     unit: selectedStyleFromGrid.unit || "Pcs",
//   };

//   return (
//     <Box sx={{ width: "100%", mt: 1 }}>
//       {/* Informative Workspace Header Context Bar */}
//       <Paper
//         variant="outlined"
//         sx={{
//           p: 2,
//           mb: 3,
//           backgroundColor: "#f5f5f5",
//           display: "flex",
//           justifyContent: "space-between",
//           alignItems: "center",
//         }}
//       >
//         <Box>
//           <Typography
//             variant="h6"
//             sx={{ fontWeight: "bold", color: "#1a237e" }}
//           >
//             [ MATERIAL CONSUMPTION MANAGEMENT WORKSPACE ]
//           </Typography>
//           <Typography variant="body2" color="text.secondary">
//             Target Style: <strong>{parentStyleContext.styleCode}</strong> |
//             Order Total:{" "}
//             <strong>
//               {parentStyleContext.bulkQuantity.toLocaleString()}{" "}
//               {parentStyleContext.unit}
//             </strong>
//           </Typography>
//         </Box>
//       </Paper>

//       {/* Primary Split-Screen Two-Pane Layout compliant with MUI v6 Grid spec */}
//       <Grid container spacing={3}>
//         {/* Left Flank Panel: Master Material Checklist Selection List (Takes up 4 out of 12 columns) */}
//         <Grid size={{ xs: 12, md: 4 }}>
//           <Paper elevation={2} sx={{ p: 2, minHeight: "500px" }}>
//             <Typography
//               variant="subtitle2"
//               sx={{ fontWeight: "bold", mb: 2, color: "#37474f" }}
//             >
//               Available Materials Inventory Checklist
//             </Typography>
//             <MaterialMasterList
//               onSelectMaterial={(selectedItem: any) => {
//                 console.log(
//                   "Selected target master material item code:",
//                   selectedItem.itemCode,
//                 );
//                 setActiveSelection(selectedItem);
//               }}
//             />
//           </Paper>
//         </Grid>

//         {/* Right Flank Panel: Dynamic Entry Data Input Form (Takes up 8 out of 12 columns) */}
//         <Grid size={{ xs: 12, md: 8 }}>
//           <Paper elevation={2} sx={{ p: 2, minHeight: "500px" }}>
//             {activeSelection ? (
//               <ConsumptionEntryForm
//                 styleContext={parentStyleContext}
//                 selectedMaterial={activeSelection}
//               />
//             ) : (
//               <Box
//                 sx={{
//                   height: "400px",
//                   color: "text.secondary",
//                   display: "flex",
//                   justifyContent: "center",
//                   alignItems: "center",
//                 }}
//               >
//                 <Typography variant="body1">
//                   ← Select an item from the left inventory checklist panel to
//                   begin entering consumption details.
//                 </Typography>
//               </Box>
//             )}
//           </Paper>
//         </Grid>
//       </Grid>
//     </Box>
//   );
// };

// export default MaterialConsumption;
