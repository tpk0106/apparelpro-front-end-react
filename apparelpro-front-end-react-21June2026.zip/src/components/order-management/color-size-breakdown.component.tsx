import { useState } from "react";
import {
  Box,
  Typography,
  Stepper,
  Step,
  StepLabel,
  Paper,
  Alert,
} from "@mui/material";
import type { Style } from "../../interfaces/OrderManagement/Style";
import ColorBreakdown from "./color-breakdown.component";
import type { LocalColorRow } from "./color-breakdown-table.component";
import SizeBreakdown from "./size-breakdown.component";
import type StyleContext from "../../interfaces/OrderManagement/StyleContext";

// 1. Move the MatrixRow interface here so it's accessible globally
export interface MatrixRow {
  sizeCode: string;
  [colorCode: string]: string | number;
}

interface WorkspaceProps {
  buyerCode: number;
  order: string;
  selectedStyleFromGrid: Style | null;
  isMatrixDirty: boolean;
  setIsMatrixDirty: (dirty: boolean) => void;
  onResetSelection: () => void;
}

const steps = ["Verify Colour Groups", "Populate Size Matrix"];

export default function ColorSizeBreakdown({
  buyerCode,
  order,
  selectedStyleFromGrid,
  // isMatrixDirty,
  setIsMatrixDirty,
  onResetSelection,
}: WorkspaceProps) {
  const [activeStep, setActiveStep] = useState<number>(0);
  const [configuredColors, setConfiguredColors] = useState<LocalColorRow[]>([]);

  // 2. Add the Matrix State Memory here at the master parent level
  const [matrixRows, setMatrixRows] = useState<MatrixRow[]>([
    { sizeCode: "S" },
    { sizeCode: "M" },
    { sizeCode: "L" },
    { sizeCode: "XL" },
  ]);

  const [prevStyleId, setPrevStyleId] = useState<string | null>(null);
  const currentStyleId = selectedStyleFromGrid
    ? `${selectedStyleFromGrid.typeCode}-${selectedStyleFromGrid.styleCode}`
    : null;

  if (currentStyleId !== prevStyleId) {
    setPrevStyleId(currentStyleId);
    setActiveStep(0);
    setConfiguredColors([]);

    // 3. Reset sizes back to blank base values ONLY when switching to an entirely different style
    setMatrixRows([
      { sizeCode: "S" },
      { sizeCode: "M" },
      { sizeCode: "L" },
      { sizeCode: "XL" },
    ]);
  }

  if (!selectedStyleFromGrid) {
    return (
      <Box sx={{ padding: "3px" }}>
        <Alert severity="info" variant="filled">
          No Style context selected. Please return to the{" "}
          <strong>[Style Details]</strong> tab and click the{" "}
          <strong>Grid matrix button</strong> on a style row to begin allocation
          formatting.
        </Alert>
      </Box>
    );
  }

  const styleContextSanitized: StyleContext = {
    buyerCode: buyerCode,
    order: order,
    typeCode: selectedStyleFromGrid.typeCode,
    styleCode: selectedStyleFromGrid.styleCode,
    quantity: Number(selectedStyleFromGrid.quantity) || 0,
    colorRatio: selectedStyleFromGrid.colorRatio?.trim().toUpperCase() || "Q",
    sizeRatio: selectedStyleFromGrid.sizeRatio?.trim().toUpperCase() || "Q",
  };

  const handleColorConfigurationComplete = (
    confirmedColors: LocalColorRow[],
  ) => {
    setConfiguredColors(confirmedColors);
    setActiveStep(1);
  };

  const handleReturnToColors = () => {
    setActiveStep(0); // Simply switches step components—matrixRows stays safely in memory!
  };

  const handleWorkflowComplete = () => {
    setActiveStep(0);
    setConfiguredColors([]);
    setIsMatrixDirty(false);
    onResetSelection();
  };

  return (
    <Box sx={{ width: "100%", mt: 1 }}>
      <Paper elevation={2} sx={{ p: 2, mb: 3, backgroundColor: "#fafafa" }}>
        <Stepper activeStep={activeStep} alternativeLabel>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
      </Paper>

      <Paper
        variant="outlined"
        sx={{
          p: 2,
          mb: 3,
          backgroundColor: "#f0f4c3",
          borderColor: "#c0ca33",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Box>
          <Typography
            variant="subtitle1"
            sx={{ fontWeight: "bold", color: "#2e7d32" }}
          >
            Active Working Target: Style Code [{" "}
            {styleContextSanitized.styleCode} ]
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Buyer: {buyerCode} | Order Ref: {order} | Bulk Target Size:{" "}
            {styleContextSanitized.quantity.toLocaleString()}{" "}
            {selectedStyleFromGrid.unit || "Pcs"}
          </Typography>
        </Box>
        <Box sx={{ textAlign: "right" }}>
          <Typography
            variant="caption"
            sx={{ fontWeight: "bold", display: "block" }}
          >
            COLOUR MODE:{" "}
            {styleContextSanitized.colorRatio === "R"
              ? "Ratio Splitting [R]"
              : "Explicit Pieces [Q]"}
          </Typography>
          <Typography
            variant="caption"
            sx={{ fontWeight: "bold", display: "block" }}
          >
            SIZE MATRIX MODE:{" "}
            {styleContextSanitized.sizeRatio === "R"
              ? "Ratio Splitting [R]"
              : "Explicit Pieces [Q]"}
          </Typography>
        </Box>
      </Paper>

      {activeStep === 0 && (
        <ColorBreakdown
          styleCode={styleContextSanitized.styleCode}
          bulkQuantity={styleContextSanitized.quantity}
          initialColors={configuredColors}
          onNextStep={handleColorConfigurationComplete}
        />
      )}

      {activeStep === 1 && (
        <SizeBreakdown
          styleContext={styleContextSanitized}
          selectedColors={configuredColors}
          onBackToColors={handleReturnToColors}
          onSaveComplete={handleWorkflowComplete}
          setIsDirty={setIsMatrixDirty}
          // 4. Pass matrix row properties down to Step 2
          matrixRows={matrixRows}
          setMatrixRows={setMatrixRows}
        />
      )}
    </Box>
  );
}
