import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

import type { Style } from "../interfaces/OrderManagement/Style";
import type { PaginationData } from "../interfaces/definitions";
import type { PaginationAPIModel } from "../interfaces/references/ApiResult";
import type { Buyer } from "../interfaces/references/Buyer";
import { APPARELPRO_ENDPOINTS } from "../api/api-configurations";
import type { OrderItemServiceModel } from "../components/material-consumption/material-consumption.types";

export interface GarmentTypeServiceModel {
  id: number;
  typeName: string;
}

export interface UnitConversionServiceModel {
  fromUnit: string;
  toUnit: string;
  measure: number;
}

export interface UnitServiceModel {
  id: number;
  code: string;
  description: string;
}

export interface CurrencyServiceModel {
  id: number;
  code: string;
  name: string;
}

export interface SelectedScopeContext {
  buyerCode: number;
  order: string;
  typeCode: number;
  styleCode: string;
  bulkQuantity: number;
  parentOrderUnit: string;
}

export const materialConsumptionApi = createApi({
  reducerPath: "materialConsumptionApi",
  // ✅ FIX 1: Declaring the tag types array allows string names to be accepted below
  tagTypes: ["ConsumptionLedger"],
  baseQuery: fetchBaseQuery({
    baseUrl: APPARELPRO_ENDPOINTS.URLS.BASEURL,
    prepareHeaders: (headers) => {
      const token = localStorage.getItem("token");
      if (token) {
        headers.set("authorization", `Bearer ${token}`);
      }
      return headers;
    },
  }),
  endpoints: (builder) => ({
    getBuyersPaged: builder.query<PaginationAPIModel<Buyer>, PaginationData>({
      query: (params) => ({
        url: APPARELPRO_ENDPOINTS.REFERENCE_SECTION.BUYER.GET_BY_PAGINATION,
        method: "GET",
        params: {
          pageNumber: params.pageIndex,
          pageSize: params.pageSize,
          sortColumn: params.sortColumn || undefined,
          sortOrder: params.sortOrder || undefined,
          filterColumn: params.filterColumn || undefined,
          filterQuery: params.filterQuery || undefined,
        },
      }),
    }),

    getOrdersByBuyer: builder.query<string[], number>({
      query: (buyerCode) => ({
        url: APPARELPRO_ENDPOINTS.ORDER_MANAGEMENT.PO.GET_ALL_POS_BY_BUYER_CODE,
        method: "GET",
        params: { buyerCode },
      }),
    }),

    getAllGarmentTypes: builder.query<GarmentTypeServiceModel[], void>({
      query: () =>
        APPARELPRO_ENDPOINTS.REFERENCE_SECTION.GARMENT_TYPE
          .GET_ALL_GARMENT_TYPES,
    }),

    getAllUnitConversions: builder.query<UnitConversionServiceModel[], void>({
      query: () =>
        APPARELPRO_ENDPOINTS.REFERENCE_SECTION.UNITCONVERSION.GET_BY_PAGINATION,
    }),

    getAllUnits: builder.query<
      PaginationAPIModel<UnitServiceModel>,
      PaginationData
    >({
      query: (params) => ({
        url: APPARELPRO_ENDPOINTS.REFERENCE_SECTION.UNIT.GET_BY_PAGINATION,
        method: "GET",
        params: {
          pageNumber: params.pageIndex,
          pageSize: params.pageSize,
          sortColumn: params.sortColumn || undefined,
          sortOrder: params.sortOrder || undefined,
          filterColumn: params.filterColumn || undefined,
          filterQuery: params.filterQuery || undefined,
        },
      }),
    }),

    getAllCurrencies: builder.query<
      PaginationAPIModel<CurrencyServiceModel>,
      PaginationData
    >({
      query: (params) => ({
        url: APPARELPRO_ENDPOINTS.REFERENCE_SECTION.CURRENCY.GET_BY_PAGINATION,
        method: "GET",
        params: {
          pageNumber: params.pageIndex,
          pageSize: params.pageSize,
          sortColumn: params.sortColumn || undefined,
          sortOrder: params.sortOrder || undefined,
          filterColumn: params.filterColumn || undefined,
          filterQuery: params.filterQuery || undefined,
        },
      }),
    }),

    getStylesByScope: builder.query<
      Style[],
      { buyerCode: number; order: string; typeCode: number }
    >({
      query: ({ buyerCode, order, typeCode }) =>
        `${APPARELPRO_ENDPOINTS.ORDER_MANAGEMENT.STYLE_DETAILS.GET_STYLE_DETAILS_BY_BUYER_AND_ORDER_AND_TYPE}/${buyerCode}/${order}/${typeCode}`,
    }),

    getDynamicFeatureHeaders: builder.query<
      any,
      { stockCode: string; itemCode: string }
    >({
      query: ({ stockCode, itemCode }) =>
        `api/materialConsumption/feature-headers?stockCode=${encodeURIComponent(stockCode)}&itemCode=${encodeURIComponent(itemCode)}`,
    }),

    calculateConsumption: builder.query<number, any>({
      query: (params) => ({
        url: "api/materialConsumption/calculate-consumption",
        method: "GET",
        params,
      }),
    }),

    getBreakdownByStyle: builder.query<
      any[],
      { buyerCode: number; order: string; typeCode: number; styleCode: string }
    >({
      query: ({ buyerCode, order, typeCode, styleCode }) => ({
        // url: "api/materialConsumption/by-style",
        url: APPARELPRO_ENDPOINTS.ORDER_MANAGEMENT.MATERIAL_CONSUMPTION
          .GET_BREAKDOWN_BY_STYLE,
        method: "GET",
        params: { buyerCode, order, typeCode, styleCode },
      }),
    }),

    saveConsumptionEntry: builder.mutation<void, any>({
      query: (payload) => ({
        url: "api/materialConsumption/save-entry",
        method: "POST",
        body: payload,
      }),
      invalidatesTags: ["ConsumptionLedger"],
    }),

    // ✅ FIX 2: Only keeping this scoped hook version (the old duplicate array one was removed)
    getAvailableMaterials: builder.query<
      OrderItemServiceModel[],
      { buyerCode: number; order: string; typeCode: number; styleCode: string }
    >({
      query: ({ buyerCode, order, typeCode, styleCode }) => ({
        // url: `api/materialConsumption/items-lookup`,
        url: APPARELPRO_ENDPOINTS.ORDER_MANAGEMENT.MATERIAL_CONSUMPTION
          .GET_AVAILABLE_MATERIALS,
        method: "GET",
        params: { buyerCode, order, typeCode, styleCode },
      }),
      providesTags: ["ConsumptionLedger"],
    }),
  }),
});

export const {
  useGetBuyersPagedQuery,
  useGetOrdersByBuyerQuery,
  useGetAllGarmentTypesQuery,
  useGetAllUnitConversionsQuery,
  useGetStylesByScopeQuery,
  useGetAllUnitsQuery,
  useGetDynamicFeatureHeadersQuery,
  useLazyCalculateConsumptionQuery,
  useGetAllCurrenciesQuery,
  useGetBreakdownByStyleQuery, // <-- EXPORTED SAFELY FOR YOUR LEDGER SHEET
  useGetAvailableMaterialsQuery, // <-- EXPORTED SAFELY FOR YOUR INVENTORY GRID
  useSaveConsumptionEntryMutation, // <-- ADD THIS EXACT MUTATION HOOK HERE
} = materialConsumptionApi;

// import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

// import type { Style } from "../interfaces/OrderManagement/Style";
// import type { PaginationData } from "../interfaces/definitions";
// import type { PaginationAPIModel } from "../interfaces/references/ApiResult";
// import type { Buyer } from "../interfaces/references/Buyer";
// import { APPARELPRO_ENDPOINTS } from "../api/api-configurations";
// import type { OrderItemServiceModel } from "../components/material-consumption/material-consumption.types";

// export interface GarmentTypeServiceModel {
//   id: number;
//   typeName: string;
// }

// export interface SelectedScopeContext {
//   buyerCode: number;
//   order: string;
//   typeCode: number;
//   styleCode: string;
//   bulkQuantity: number;
//   parentOrderUnit: string;
// }

// export const materialConsumptionApi = createApi({
//   reducerPath: "materialConsumptionApi",
//   baseQuery: fetchBaseQuery({
//     baseUrl: APPARELPRO_ENDPOINTS.URLS.BASEURL,
//     prepareHeaders: (headers) => {
//       const token = localStorage.getItem("token");
//       if (token) {
//         headers.set("authorization", `Bearer ${token}`);
//       }
//       return headers;
//     },
//   }),
//   endpoints: (builder) => ({
//     getBuyersPaged: builder.query<PaginationAPIModel<Buyer>, PaginationData>({
//       query: (params) => ({
//         url: APPARELPRO_ENDPOINTS.REFERENCE_SECTION.BUYER.GET_BY_PAGINATION,
//         method: "GET",
//         params: {
//           pageNumber: params.pageIndex,
//           pageSize: params.pageSize,
//           sortColumn: params.sortColumn || undefined,
//           sortOrder: params.sortOrder || undefined,
//           filterColumn: params.filterColumn || undefined,
//           filterQuery: params.filterQuery || undefined,
//         },
//       }),
//     }),

//     // `${APPARELPRO_ENDPOINTS.ORDER_MANAGEMENT.PO.GET_ALL_POS_BY_BUYER_CODE}/${buyerCode}`,
//     getOrdersByBuyer: builder.query<string[], number>({
//       query: (buyerCode) => ({
//         url: APPARELPRO_ENDPOINTS.ORDER_MANAGEMENT.PO.GET_ALL_POS_BY_BUYER_CODE,
//         method: "GET",
//         params: { buyerCode },
//       }),
//     }),

//     getAllGarmentTypes: builder.query<GarmentTypeServiceModel[], void>({
//       query: () =>
//         APPARELPRO_ENDPOINTS.REFERENCE_SECTION.GARMENT_TYPE
//           .GET_ALL_GARMENT_TYPES,
//     }),

//     getStylesByScope: builder.query<
//       Style[],
//       { buyerCode: number; order: string; typeCode: number }
//     >({
//       query: ({ buyerCode, order, typeCode }) =>
//         `${APPARELPRO_ENDPOINTS.ORDER_MANAGEMENT.STYLE_DETAILS.GET_STYLE_DETAILS_BY_BUYER_AND_ORDER_AND_TYPE}/${buyerCode}/${order}/${typeCode}`,
//     }),

//     getDynamicFeatureHeaders: builder.query<
//       any,
//       { stockCode: string; itemCode: string }
//     >({
//       query: ({ stockCode, itemCode }) =>
//         `api/materialConsumption/feature-headers?stockCode=${encodeURIComponent(stockCode)}&itemCode=${encodeURIComponent(itemCode)}`,
//     }),

//     calculateConsumption: builder.query<number, any>({
//       query: (params) => ({
//         url: "api/materialConsumption/calculate-consumption",
//         method: "GET",
//         params,
//       }),
//     }),

//     // 1. ADDED: Fetch the active ledger breakdown spreadsheet records out of SQL Server
//     getBreakdownByStyle: builder.query<
//       any[],
//       { buyerCode: number; order: string; typeCode: number; styleCode: string }
//     >({
//       query: ({ buyerCode, order, typeCode, styleCode }) => ({
//         url: "api/materialConsumption/by-style", // Matches your C# controller GET path route
//         method: "GET",
//         params: { buyerCode, order, typeCode, styleCode },
//       }),
//     }),

//     // 2. ADDED: Left-Flank Master Material Checklist Selection Lookup Endpoint
//     getAvailableMaterials: builder.query<any[], void>({
//       query: () => "api/materialConsumption/items-lookup",
//     }),

//     // Inside endpoints block in material-consumption.services.ts:
//     saveConsumptionEntry: builder.mutation<void, any>({
//       query: (payload) => ({
//         url: "api/materialConsumption/save-entry", // Your target C# Controller route path
//         method: "POST",
//         body: payload,
//       }),
//       // Invalidates the cache tag to force the bottom grid to refresh automatically
//       invalidatesTags: ["ConsumptionLedger"],
//     }),

//     // Inside your material-consumption.services.ts file:
//     getAvailableMaterials: builder.query<
//       OrderItemServiceModel[],
//       { buyerCode: number; order: string; typeCode: number; styleCode: string }
//     >({
//       query: ({ buyerCode, order, typeCode, styleCode }) => ({
//         url: `api/materialConsumption/items-lookup`,
//         method: "GET",
//         params: { buyerCode, order, typeCode, styleCode },
//       }),
//       providesTags: ["ConsumptionLedger"],
//     }),
//   }),
// });

// export const {
//   useGetBuyersPagedQuery,
//   useGetOrdersByBuyerQuery,
//   useGetAllGarmentTypesQuery,
//   useGetStylesByScopeQuery,
//   useGetDynamicFeatureHeadersQuery,
//   useLazyCalculateConsumptionQuery,
//   useGetBreakdownByStyleQuery, // <-- EXPORTED SAFELY FOR YOUR LEDGER SHEET
//   useGetAvailableMaterialsQuery, // <-- EXPORTED SAFELY FOR YOUR INVENTORY GRID
//   useSaveConsumptionEntryMutation, // <-- ADD THIS EXACT MUTATION HOOK HERE
// } = materialConsumptionApi;

// // export const materialConsumptionApi = createApi({
// //   reducerPath: "materialConsumptionApi",
// //   baseQuery: fetchBaseQuery({
// //     baseUrl: "/", // Base URL prefix; sub-paths handle relative routing
// //     prepareHeaders: (headers) => {
// //       const token = localStorage.getItem("token");
// //       if (token) {
// //         headers.set("authorization", `Bearer ${token}`);
// //       }
// //       return headers;
// //     },
// //   }),
// //   endpoints: (builder) => ({
// //     // 2. FIXED: Fully synchronized using your corporate PaginationAPIModel<Buyer> mapping
// //     getBuyersPaged: builder.query<PaginationAPIModel<Buyer>, PaginationData>({
// //       query: (params) => ({
// //         url: APPARELPRO_ENDPOINTS.REFERENCE_SECTION.BUYER.GET_BY_PAGINATION, // "api/buyer/list"
// //         method: "GET",
// //         params: {
// //           pageNumber: params.pageIndex, // Maps your pageIndex to C# pageNumber query param
// //           pageSize: params.pageSize,
// //           sortColumn: params.sortColumn || undefined,
// //           sortOrder: params.sortOrder || undefined,
// //           filterColumn: params.filterColumn || undefined,
// //           filterQuery: params.filterQuery || undefined,
// //         },
// //       }),
// //     }),

// //     // 3. Purchase Order Numbers Lookup
// //     getOrdersByBuyer: builder.query<string[], number>({
// //       query: (buyerCode) =>
// //         `${APPARELPRO_ENDPOINTS.ORDER_MANAGEMENT.PO.GET_ALL_POS_BY_BUYER_CODE}/${buyerCode}`,
// //     }),

// //     // 4. Reference Garment Types Lookup
// //     getAllGarmentTypes: builder.query<GarmentTypeServiceModel[], void>({
// //       query: () =>
// //         APPARELPRO_ENDPOINTS.REFERENCE_SECTION.GARMENT_TYPE
// //           .GET_ALL_GARMENT_TYPES,
// //     }),

// //     // 5. Styles List Filtering
// //     getStylesByScope: builder.query<
// //       Style[],
// //       { buyerCode: number; order: string; typeCode: number }
// //     >({
// //       query: ({ buyerCode, order, typeCode }) => ({
// //         url: APPARELPRO_ENDPOINTS.ORDER_MANAGEMENT.STYLE_DETAILS
// //           .GET_STYLE_DETAILS_BY_BUYER_AND_ORDER,
// //         method: "GET",
// //         params: { buyerCode, order, typeCode },
// //       }),
// //     }),

// //     // 1. MAKE SURE THIS ENDPOINT IS REGISTERED IN THE ENDPOINTS BLOCK:
// //     getDynamicFeatureHeaders: builder.query<
// //       any,
// //       { stockCode: string; itemCode: string }
// //     >({
// //       query: ({ stockCode, itemCode }) =>
// //         `api/materialConsumption/feature-headers?stockCode=${encodeURIComponent(stockCode)}&itemCode=${encodeURIComponent(itemCode)}`,
// //     }),

// //     // 2. MAKE SURE THIS ENDPOINT IS ALSO REGISTERED HERE FOR THE MATH ENGINE:
// //     calculateConsumption: builder.query<number, any>({
// //       query: (params) => ({
// //         url: "api/materialConsumption/calculate-consumption",
// //         method: "GET",
// //         params,
// //       }),
// //     }),
// //   }),
// // });

// // export const {
// //   useGetBuyersPagedQuery,
// //   useGetOrdersByBuyerQuery,
// //   useGetAllGarmentTypesQuery,
// //   useGetStylesByScopeQuery,
// //   useGetDynamicFeatureHeadersQuery,
// //   useLazyCalculateConsumptionQuery,
// // } = materialConsumptionApi;
