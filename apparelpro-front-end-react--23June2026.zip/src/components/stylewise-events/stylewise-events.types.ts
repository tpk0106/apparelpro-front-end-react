export interface StylewiseEventRow {
  id: number;
  buyerCode: number;
  order: string;
  typeCode: number;
  styleCode: string;
  eventCode: string;
  description: string;
  scheduledDate: string | null; // Transported as ISO string dates or null
  actualDate: string | null;
  remarks: string | null;
  milestoneStatus: string; // "No Scheduled Date", "Actual Date Pending", or "** OK **"
}

export interface UpdateEventLinePayload {
  buyerCode: number;
  order: string;
  typeCode: number;
  styleCode: string;
  eventCode: string;
  scheduledDate: string | null;
  actualDate: string | null;
  remarks: string | null;
}

export interface AddCustomEventLinePayload {
  buyerCode: number;
  order: string;
  typeCode: number;
  styleCode: string;
  eventCode: string;
  scheduledDate: string | null;
  actualDate: string | null;
  remarks: string | null;
}

export interface DeleteEventLineParams {
  buyerCode: number;
  order: string;
  typeCode: number;
  styleCode: string;
  eventCode: string;
}

// Open stylewise-events.types.ts and append this explicit mapping schema context contract:
export interface SelectedHeaderContext {
  buyerCode: number;
  order: string;
  typeCode: number;
  styleCode: string;
}

// Your existing definitions for StylewiseEventRow, UpdateEventLinePayload, etc., continue perfectly unchanged!
